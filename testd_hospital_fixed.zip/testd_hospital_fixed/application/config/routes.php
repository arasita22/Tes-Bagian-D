<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'hospital';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['dashboard'] = 'hospital/dashboard';
$route['pasien'] = 'hospital/pasien';
$route['dokter'] = 'hospital/dokter';
$route['kunjungan'] = 'hospital/kunjungan';
$route['unit'] = 'hospital/unit';
$route['diagnosis'] = 'hospital/diagnosis';
$route['api/dashboard/summary'] = 'api/summary';
$route['api/dashboard'] = 'api/dashboard';
$route['api/patients'] = 'api/patients';