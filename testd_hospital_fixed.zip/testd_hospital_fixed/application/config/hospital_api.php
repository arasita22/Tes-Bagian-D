<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Ganti URL ini sesuai alamat REST API dari dokumentasi/Postman kamu.
$config['hospital_api_base_url'] = 'http://localhost:3000/api';
$config['hospital_api_token'] = '';
