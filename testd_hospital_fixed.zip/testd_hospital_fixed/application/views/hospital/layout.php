
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$page = isset($page) ? $page : 'dashboard';
$title = isset($title) ? $title : 'Dashboard';
$base = base_url();
$links = array(
    'dashboard' => array('Dashboard', 'hospital'),
    'pasien' => array('Data Pasien', 'hospital/pasien'),
    'kunjungan' => array('Kunjungan', 'hospital/kunjungan'),
    'dokter' => array('Data Dokter', 'hospital/dokter'),
    'unit' => array('Unit / Poli', 'hospital/unit'),
    'diagnosis' => array('Diagnosis', 'hospital/diagnosis')
);

$patients = array(
    array('RM-2026-001', 'Andi Pratama', 'Laki-laki', '28 th', 'Aktif'),
    array('RM-2026-002', 'Siti Rahmawati', 'Perempuan', '34 th', 'Aktif'),
    array('RM-2026-003', 'Budi Santoso', 'Laki-laki', '45 th', 'Aktif'),
    array('RM-2026-004', 'Dewi Anggraini', 'Perempuan', '22 th', 'Aktif'),
    array('RM-2026-005', 'Rizky Maulana', 'Laki-laki', '31 th', 'Aktif')
);
$visits = array(
    array('KJ-001', 'Andi Pratama', 'Poli Umum', 'Dr. Aditya Putra', '09:15', 'Selesai'),
    array('KJ-002', 'Siti Rahmawati', 'Poli Gigi', 'Dr. Nadia Putri', '09:30', 'Berlangsung'),
    array('KJ-003', 'Budi Santoso', 'Poli Jantung', 'Dr. R. Firmansyah', '10:00', 'Menunggu'),
    array('KJ-004', 'Dewi Anggraini', 'Poli Anak', 'Dr. Nadia Putri', '10:30', 'Menunggu'),
    array('KJ-005', 'Rizky Maulana', 'Poli Umum', 'Dr. Aditya Putra', '11:00', 'Selesai')
);
$doctors = array(
    array('DR-001', 'Dr. Aditya Putra', 'Poli Umum', 'Senin - Jumat', 'Aktif'),
    array('DR-002', 'Dr. Nadia Putri', 'Poli Gigi', 'Senin - Sabtu', 'Aktif'),
    array('DR-003', 'Dr. R. Firmansyah', 'Poli Jantung', 'Senin - Kamis', 'Aktif'),
    array('DR-004', 'Dr. Maya Lestari', 'Poli Anak', 'Selasa - Sabtu', 'Aktif')
);
$units = array(
    array('UNT-001', 'Poli Umum', 'Dr. Aditya Putra', '08:00 - 14:00', 'Buka'),
    array('UNT-002', 'Poli Gigi', 'Dr. Nadia Putri', '08:00 - 16:00', 'Buka'),
    array('UNT-003', 'Poli Jantung', 'Dr. R. Firmansyah', '09:00 - 13:00', 'Buka'),
    array('UNT-004', 'Poli Anak', 'Dr. Maya Lestari', '08:00 - 15:00', 'Buka')
);
$diagnoses = array(
    array('DG-001', 'Hipertensi', 'Kardiovaskular', 'KJ-003', 'Aktif'),
    array('DG-002', 'ISPA', 'Pernapasan', 'KJ-001', 'Selesai'),
    array('DG-003', 'Karies Gigi', 'Gigi dan Mulut', 'KJ-002', 'Selesai'),
    array('DG-004', 'Demam', 'Umum', 'KJ-004', 'Aktif')
);

$rows = array();
$headers = array();
if ($page === 'pasien') {
    $headers = array('No. Rekam Medis', 'Nama Pasien', 'Jenis Kelamin', 'Usia', 'Status');
    $rows = $patients;
} elseif ($page === 'kunjungan' || $page === 'dashboard') {
    $headers = array('ID Kunjungan', 'Nama Pasien', 'Unit / Poli', 'Dokter', 'Jam', 'Status');
    $rows = $visits;
} elseif ($page === 'dokter') {
    $headers = array('ID Dokter', 'Nama Dokter', 'Spesialisasi', 'Jadwal Praktik', 'Status');
    $rows = $doctors;
} elseif ($page === 'unit') {
    $headers = array('ID Unit', 'Nama Unit', 'Dokter', 'Jam Operasional', 'Status');
    $rows = $units;
} elseif ($page === 'diagnosis') {
    $headers = array('ID Diagnosis', 'Diagnosis', 'Kategori', 'ID Kunjungan', 'Status');
    $rows = $diagnoses;
}

$apiError = isset($api_result) && empty($api_result['success']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= html_escape($title) ?> | Santosa Care</title>
<style>
:root {
    --primary: #176b61;
    --primary-dark: #10554d;
    --primary-light: #e5f4ef;
    --bg: #f5f7fa;
    --white: #fff;
    --text: #172b36;
    --muted: #82919b;
    --border: #e9eef1;
    --orange: #f1a35b;
    --red: #d75b64;
    --blue: #5b8def;
    --shadow: 0 4px 18px rgba(24,49,61,.045);
}
* { box-sizing: border-box; }
body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: Inter, "Segoe UI", Arial, sans-serif;
    font-size: 13px;
}
button, input, select { font: inherit; }
button { cursor: pointer; }
a { text-decoration: none; color: inherit; }
.app { min-height: 100vh; }
.sidebar {
    width: 245px;
    background: #fff;
    border-right: 1px solid var(--border);
    position: fixed;
    inset: 0 auto 0 0;
    padding: 27px 18px;
    z-index: 20;
    display: flex;
    flex-direction: column;
}
.brand { display:flex; align-items:center; gap:12px; padding:0 9px 35px; }
.brand-icon {
    height: 43px; width:43px; border-radius:13px;
    background:var(--primary); color:white; display:grid; place-items:center;
    font-size:25px; font-weight:300;
}
.brand-name { font-size:19px; font-weight:800; letter-spacing:-.6px; }
.brand-name span { color:var(--primary); }
.brand-sub { font-size:8px; color:#95a3aa; letter-spacing:1.5px; margin-top:5px; }
.nav-label {
    color:#a0abb2; font-size:10px; font-weight:700;
    letter-spacing:1.5px; padding:0 12px; margin:10px 0 13px;
}
.nav { display:flex; flex-direction:column; gap:5px; }
.nav a {
    padding:12px 13px; display:flex; align-items:center; gap:13px;
    color:#75858e; border-radius:9px; font-weight:600; transition:.2s;
}
.nav a:hover { background:#f4f8f7; color:var(--primary); }
.nav a.active { background:var(--primary-light); color:var(--primary); }
.nav-icon { width:20px; text-align:center; font-size:17px; }
.sidebar-bottom {
    margin-top:auto; padding:17px 12px 0; border-top:1px solid var(--border);
}
.help-card { background:#f2f8f6; padding:15px; border-radius:12px; }
.help-card strong { display:block; font-size:12px; margin-bottom:7px; }
.help-card p { color:var(--muted); font-size:11px; line-height:1.6; margin:0 0 12px; }
.help-card a { color:var(--primary); font-weight:700; font-size:11px; }
.main { margin-left:245px; min-height:100vh; }
.topbar {
    height:76px; background:#fff; border-bottom:1px solid var(--border);
    display:flex; align-items:center; justify-content:space-between;
    padding:0 34px; position:sticky; top:0; z-index:10;
}
.top-left { display:flex; align-items:center; gap:17px; }
.breadcrumb { color:#9aa6ac; font-size:12px; }
.breadcrumb strong { color:#334a54; font-weight:700; }
.top-right { display:flex; align-items:center; gap:20px; }
.icon-button {
    border:1px solid var(--border); background:white; height:37px; width:37px;
    border-radius:10px; position:relative; color:#657781; font-size:16px;
}
.dot {
    height:7px; width:7px; border-radius:50%; background:#e66f75;
    position:absolute; top:7px; right:7px; border:1px solid white;
}
.profile { display:flex; align-items:center; gap:10px; }
.avatar {
    width:37px; height:37px; border-radius:12px; background:#dcefe8;
    color:var(--primary); display:grid; place-items:center; font-weight:800;
}
.profile-name { font-weight:700; font-size:12px; }
.profile-role { color:#99a6ad; font-size:10px; margin-top:4px; }
.content { max-width:1600px; margin:auto; padding:30px 34px 40px; }
.welcome {
    display:flex; justify-content:space-between; align-items:center;
    gap:20px; margin-bottom:25px;
}
.eyebrow {
    color:var(--primary); font-size:10px; font-weight:800;
    letter-spacing:1.7px; margin-bottom:10px;
}
h1 { font-size:26px; letter-spacing:-.7px; margin:0 0 9px; }
.subtitle { color:#8a999f; margin:0; font-size:12px; line-height:1.6; }
.welcome-actions { display:flex; gap:10px; flex-wrap:wrap; }
.btn {
    border:1px solid #e3e9ec; border-radius:9px; padding:11px 15px;
    background:white; color:#50636d; font-weight:700; font-size:11px;
    display:inline-flex; align-items:center; justify-content:center; gap:8px;
}
.btn-primary { background:var(--primary); border-color:var(--primary); color:white; }
.btn-primary:hover { background:var(--primary-dark); }
.stats {
    display:grid; grid-template-columns:repeat(4,minmax(0,1fr));
    gap:17px; margin-bottom:23px;
}
.stat {
    background:white; border:1px solid var(--border); border-radius:13px;
    padding:20px; box-shadow:var(--shadow); min-width:0;
}
.stat-top { display:flex; align-items:center; justify-content:space-between; gap:8px; }
.stat-label { color:#8c9ba2; font-size:11px; font-weight:600; }
.stat-icon {
    width:39px; height:39px; border-radius:11px; display:grid;
    place-items:center; font-size:18px;
}
.ic-green { background:#e4f4ed; color:#24816d; }
.ic-orange { background:#fff0e2; color:#db8d41; }
.ic-blue { background:#e8efff; color:#6085db; }
.ic-red { background:#fce9eb; color:#d66b74; }
.stat-value { font-size:27px; font-weight:800; margin:15px 0 9px; letter-spacing:-.7px; }
.stat-foot { display:flex; align-items:center; gap:7px; color:#9aa6ad; font-size:10px; }
.trend { color:#218b6b; background:#e8f7ef; padding:4px 6px; border-radius:5px; font-weight:800; }
.dashboard-grid {
    display:grid; grid-template-columns:minmax(0,1.65fr) minmax(270px,1fr);
    gap:20px; margin-bottom:22px;
}
.panel {
    background:white; border:1px solid var(--border); border-radius:13px;
    box-shadow:var(--shadow); min-width:0; overflow:hidden;
}
.panel-head {
    padding:21px 22px; display:flex; justify-content:space-between;
    align-items:center; gap:12px; border-bottom:1px solid #f0f3f5;
}
.panel-head h2 { margin:0; font-size:14px; }
.panel-head p { margin:6px 0 0; color:#9aa6ad; font-size:11px; }
.period {
    border:1px solid var(--border); border-radius:7px; padding:8px 10px;
    color:#62747d; background:white; font-size:10px;
}
.chart-area { padding:20px 20px 14px; }
.chart-legend { display:flex; gap:18px; font-size:10px; color:#7f9098; margin-bottom:22px; }
.legend-dot { display:inline-block; width:8px; height:8px; border-radius:3px; margin-right:6px; }
.chart {
    height:195px; display:grid; grid-template-columns:repeat(7,1fr);
    gap:13px; position:relative; padding:0 5px 26px;
    border-bottom:1px solid var(--border);
    background:repeating-linear-gradient(to bottom,transparent 0,transparent 47px,#eef2f4 48px);
}
.chart-col { height:100%; display:flex; align-items:flex-end; justify-content:center; gap:5px; position:relative; }
.bar { width:min(20px,40%); border-radius:5px 5px 0 0; min-height:8px; }
.bar-a { background:#1d7669; }
.bar-b { background:#b8dfd2; }
.chart-day { position:absolute; bottom:-22px; font-size:10px; color:#9aa6ad; }
.legend-dot.green { background:#1d7669; }
.legend-dot.mint { background:#b8dfd2; }
.chart-note { margin-top:28px; display:flex; justify-content:space-between; color:#8c9ba2; font-size:10px; }
.chart-note strong { color:var(--primary); }
.activity-list { padding:6px 21px 14px; }
.activity {
    display:flex; gap:12px; align-items:flex-start;
    padding:14px 0; border-bottom:1px solid #f0f3f5;
}
.activity:last-child { border-bottom:0; }
.activity-icon {
    width:34px; height:34px; border-radius:10px;
    display:grid; place-items:center; flex-shrink:0; font-size:15px;
}
.activity strong { font-size:11px; display:block; margin:2px 0 5px; }
.activity p { color:#94a1a8; font-size:10px; line-height:1.5; margin:0; }
.activity time { color:#a2adb3; font-size:9px; display:block; margin-top:7px; }
.table-panel { margin-bottom:22px; }
.table-tools {
    padding:17px 21px; display:flex; justify-content:space-between;
    align-items:center; gap:12px; flex-wrap:wrap;
}
.search {
    display:flex; align-items:center; gap:9px; padding:10px 12px;
    border:1px solid var(--border); border-radius:8px; min-width:220px;
    background:white; color:#8c9ba2;
}
.search input { border:0; outline:0; width:100%; min-width:0; color:var(--text); }
.table-scroll { overflow-x:auto; }
table { width:100%; border-collapse:collapse; white-space:nowrap; }
thead { background:#f8fafb; }
th {
    color:#8b9aa1; text-align:left; padding:13px 21px;
    font-size:9px; font-weight:800; letter-spacing:.6px;
}
td {
    padding:15px 21px; border-bottom:1px solid #f0f3f5;
    font-size:11px; color:#566a74;
}
tbody tr:last-child td { border-bottom:0; }
tbody tr:hover { background:#fbfdfc; }
.patient { display:flex; align-items:center; gap:10px; }
.patient-avatar {
    width:32px; height:32px; display:grid; place-items:center;
    border-radius:10px; background:#e9f3ef; color:var(--primary);
    font-weight:800; font-size:10px;
}
.patient-name { color:#273e48; font-weight:700; }
.patient-id { color:#9ca8ae; font-size:9px; margin-top:4px; }
.status {
    display:inline-block; padding:6px 9px; border-radius:6px;
    font-size:9px; font-weight:800;
}
.status-green { background:#e7f6ed; color:#288360; }
.status-orange { background:#fff2e4; color:#c48239; }
.status-blue { background:#e9efff; color:#547bd0; }
.status-red { background:#fdebed; color:#cc5963; }
.table-footer {
    display:flex; justify-content:space-between; align-items:center;
    padding:15px 21px; color:#99a6ac; font-size:10px;
    border-top:1px solid #f0f3f5;
}
.pagination { display:flex; gap:5px; }
.pagination button {
    border:1px solid var(--border); background:white; color:#71828b;
    border-radius:6px; min-width:27px; height:27px;
}
.pagination button.active { background:var(--primary); color:white; border-color:var(--primary); }
.bottom-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.quick-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:12px; padding:20px; }
.quick-link {
    border:1px solid var(--border); border-radius:10px; padding:15px;
    display:flex; align-items:center; gap:12px; transition:.2s;
}
.quick-link:hover { border-color:#a9d3c6; background:#f9fcfa; }
.quick-icon {
    height:38px; width:38px; border-radius:10px;
    display:grid; place-items:center; font-size:17px; flex-shrink:0;
}
.quick-link strong { display:block; font-size:11px; margin-bottom:5px; }
.quick-link small { color:#9aa6ad; font-size:9px; }
.notice {
    padding:14px 17px; margin-bottom:20px; border-radius:10px;
    background:#fff5e9; color:#956526; border:1px solid #f3e2c7;
    line-height:1.6;
}
.notice p { margin:4px 0 0; }
.footer { padding:15px 0 0; text-align:center; color:#a1adb3; font-size:10px; }
.mobile-menu { display:none; }
.empty { padding:28px; text-align:center; color:#9aa6ad; }
@media(max-width:1150px) {
    .stats { grid-template-columns:repeat(2,minmax(0,1fr)); }
    .dashboard-grid { grid-template-columns:1fr; }
}
@media(max-width:760px) {
    .sidebar { transform:translateX(-100%); transition:.25s; box-shadow:none; }
    .sidebar.open { transform:translateX(0); box-shadow:10px 0 35px #102b321c; }
    .main { margin-left:0; }
    .topbar { padding:0 17px; height:65px; }
    .mobile-menu { display:inline-grid; place-items:center; }
    .profile-info { display:none; }
    .content { padding:23px 15px; }
    .welcome { align-items:flex-start; flex-direction:column; }
    h1 { font-size:23px; }
    .stats { gap:10px; }
    .stat { padding:15px; }
    .stat-value { font-size:23px; }
    .bottom-grid { grid-template-columns:1fr; }
    .panel-head { padding:17px; }
    .table-tools { padding:14px; }
    .search { min-width:100%; }
    th, td { padding:13px 15px; }
}
@media(max-width:390px) {
    .stats { grid-template-columns:1fr 1fr; }
    .stat { padding:12px; }
    .stat-value { font-size:21px; }
    .quick-grid { grid-template-columns:1fr; }
}
</style>
</head>
<body>
<div class="app">
<aside class="sidebar" id="sidebar">
    <a href="<?= site_url('hospital') ?>" class="brand">
        <div class="brand-icon">✚</div>
        <div>
            <div class="brand-name">Santosa<span>Care</span></div>
            <div class="brand-sub">HOSPITAL INFORMATION</div>
        </div>
    </a>

    <div class="nav-label">MENU UTAMA</div>
    <nav class="nav">
        <?php foreach ($links as $key => $item): ?>
        <a href="<?= site_url($item[1]) ?>"
           class="<?= $page === $key ? 'active' : '' ?>">
            <span class="nav-icon">
                <?php
                $icons = array(
                    'dashboard'=>'▦','pasien'=>'♙','kunjungan'=>'▤',
                    'dokter'=>'✚','unit'=>'⊞','diagnosis'=>'♡'
                );
                echo $icons[$key];
                ?>
            </span>
            <?= html_escape($item[0]) ?>
        </a>
        <?php endforeach; ?>
    </nav>

    <div class="sidebar-bottom">
        <div class="help-card">
            <strong>Butuh bantuan?</strong>
            <p>Hubungi administrator sistem jika mengalami kendala.</p>
            <a href="mailto:admin@hospital.local">Hubungi Admin ↗</a>
        </div>
        <div style="color:#a2adb3;font-size:9px;margin:18px 4px 0">
            © <?= date('Y') ?> Santosa Care HIS
        </div>
    </div>
</aside>

<main class="main">
    <header class="topbar">
        <div class="top-left">
            <button class="icon-button mobile-menu" onclick="toggleSidebar()">☰</button>
            <div class="breadcrumb">Hospital / <strong><?= html_escape($title) ?></strong></div>
        </div>
        <div class="top-right">
            <button class="icon-button" title="Notifikasi" onclick="alert('Belum ada notifikasi baru.')">
                ♧<span class="dot"></span>
            </button>
            <div class="profile">
                <div class="avatar">AD</div>
                <div class="profile-info">
                    <div class="profile-name">Administrator</div>
                    <div class="profile-role">System Admin</div>
                </div>
            </div>
        </div>
    </header>

    <section class="content">
        <div class="welcome">
            <div>
                <div class="eyebrow">HOSPITAL INFORMATION SYSTEM</div>
                <h1>
                    <?php
                    echo $page === 'dashboard'
                        ? 'Selamat Datang, Admin!'
                        : html_escape($title);
                    ?>
                </h1>
                <p class="subtitle">
                    <?php if ($page === 'dashboard'): ?>
                        Pantau aktivitas rumah sakit dan informasi layanan hari ini.
                    <?php else: ?>
                        Kelola informasi <?= strtolower(html_escape($title)) ?> dalam satu tempat.
                    <?php endif; ?>
                </p>
            </div>
            <div class="welcome-actions">
                <button class="btn" onclick="window.print()">▧ Cetak Laporan</button>
                <?php if ($page === 'pasien' || $page === 'kunjungan'): ?>
                    <button class="btn btn-primary" onclick="showForm()">＋ Tambah Data</button>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($apiError): ?>
        <div class="notice">
            <strong>ⓘ API belum terhubung</strong>
            <p>
                <?= html_escape(
                    isset($api_result['message'])
                    ? $api_result['message']
                    : 'Periksa konfigurasi API.'
                ) ?>
                Tampilan saat ini menggunakan data contoh.
            </p>
        </div>
        <?php endif; ?>

        <?php if ($page === 'dashboard'): ?>
        <div class="stats">
            <div class="stat">
                <div class="stat-top">
                    <span class="stat-label">Total Pasien</span>
                    <span class="stat-icon ic-green">♙</span>
                </div>
                <div class="stat-value">1,284</div>
                <div class="stat-foot"><span class="trend">↑ 12.8%</span> dibanding bulan lalu</div>
            </div>
            <div class="stat">
                <div class="stat-top">
                    <span class="stat-label">Kunjungan Hari Ini</span>
                    <span class="stat-icon ic-orange">▤</span>
                </div>
                <div class="stat-value">156</div>
                <div class="stat-foot"><span class="trend">↑ 8.2%</span> dibanding kemarin</div>
            </div>
            <div class="stat">
                <div class="stat-top">
                    <span class="stat-label">Dokter Aktif</span>
                    <span class="stat-icon ic-blue">✚</span>
                </div>
                <div class="stat-value">48</div>
                <div class="stat-foot">Dokter dari berbagai spesialisasi</div>
            </div>
            <div class="stat">
                <div class="stat-top">
                    <span class="stat-label">Unit / Poli</span>
                    <span class="stat-icon ic-red">⊞</span>
                </div>
                <div class="stat-value">12</div>
                <div class="stat-foot">Unit pelayanan tersedia</div>
            </div>
        </div>

        <div class="dashboard-grid">
            <section class="panel">
                <div class="panel-head">
                    <div>
                        <h2>Statistik Kunjungan</h2>
                        <p>Ringkasan aktivitas kunjungan pasien</p>
                    </div>
                    <select class="period" id="chartPeriod" onchange="changeChart()">
                        <option value="week">7 Hari Terakhir</option>
                        <option value="month">Bulanan</option>
                    </select>
                </div>
                <div class="chart-area">
                    <div class="chart-legend">
                        <span><i class="legend-dot green"></i>Kunjungan</span>
                        <span><i class="legend-dot mint"></i>Pasien Baru</span>
                    </div>
                    <div class="chart" id="chart">
                        <?php
                        $barA = array(45,67,55,82,61,92,73);
                        $barB = array(25,38,32,44,29,53,40);
                        $days = array('Sen','Sel','Rab','Kam','Jum','Sab','Min');
                        foreach ($barA as $i => $height):
                        ?>
                        <div class="chart-col">
                            <div class="bar bar-a" style="height:<?= $height ?>%"></div>
                            <div class="bar bar-b" style="height:<?= $barB[$i] ?>%"></div>
                            <span class="chart-day"><?= $days[$i] ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="chart-note">
                        <span>Data ilustrasi untuk tampilan awal</span>
                        <strong>Periode berjalan ↗</strong>
                    </div>
                </div>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <div>
                        <h2>Aktivitas Terbaru</h2>
                        <p>Aktivitas sistem rumah sakit</p>
                    </div>
                    <button class="btn" onclick="alert('Aktivitas terbaru')">•••</button>
                </div>
                <div class="activity-list">
                    <div class="activity">
                        <div class="activity-icon ic-green">♙</div>
                        <div>
                            <strong>Pasien baru terdaftar</strong>
                            <p>Andi Pratama · Rekam medis baru</p>
                            <time>09:15 WIB</time>
                        </div>
                    </div>
                    <div class="activity">
                        <div class="activity-icon ic-blue">▤</div>
                        <div>
                            <strong>Kunjungan dibuat</strong>
                            <p>Siti Rahmawati · Poli Gigi</p>
                            <time>09:30 WIB</time>
                        </div>
                    </div>
                    <div class="activity">
                        <div class="activity-icon ic-orange">✚</div>
                        <div>
                            <strong>Jadwal dokter diperbarui</strong>
                            <p>Dr. Aditya Putra · Poli Umum</p>
                            <time>09:45 WIB</time>
                        </div>
                    </div>
                    <div class="activity">
                        <div class="activity-icon ic-red">♡</div>
                        <div>
                            <strong>Diagnosis dicatat</strong>
                            <p>Data diagnosis kunjungan diperbarui</p>
                            <time>10:00 WIB</time>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <section class="panel table-panel">
            <div class="panel-head">
                <div>
                    <h2>Kunjungan Terbaru</h2>
                    <p>Daftar kunjungan pasien hari ini</p>
                </div>
                <a class="btn" href="<?= site_url('hospital/kunjungan') ?>">Lihat Semua ↗</a>
            </div>
            <div class="table-tools">
                <label class="search">⌕
                    <input id="tableSearch" type="search" placeholder="Cari pasien atau dokter..." oninput="filterTable()">
                </label>
                <button class="btn" onclick="window.print()">⇩ Ekspor / Cetak</button>
            </div>
            <div class="table-scroll">
                <table id="dataTable">
                    <thead><tr>
                        <th>ID KUNJUNGAN</th><th>PASIEN</th><th>UNIT / POLI</th>
                        <th>DOKTER</th><th>JAM</th><th>STATUS</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($visits as $v): ?>
                    <tr>
                        <td><strong><?= html_escape($v[0]) ?></strong></td>
                        <td><div class="patient">
                            <div class="patient-avatar"><?= html_escape(strtoupper(substr($v[1],0,1))) ?></div>
                            <div><div class="patient-name"><?= html_escape($v[1]) ?></div><div class="patient-id">Pasien terdaftar</div></div>
                        </div></td>
                        <td><?= html_escape($v[2]) ?></td>
                        <td><?= html_escape($v[3]) ?></td>
                        <td><?= html_escape($v[4]) ?></td>
                        <td>
                            <?php
                            $cls = $v[5] === 'Selesai' ? 'status-green' :
                                ($v[5] === 'Berlangsung' ? 'status-blue' : 'status-orange');
                            ?>
                            <span class="status <?= $cls ?>"><?= html_escape($v[5]) ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="table-footer">
                <span>Menampilkan 5 dari 156 kunjungan (data ilustrasi)</span>
                <div class="pagination">
                    <button>‹</button><button class="active">1</button><button>2</button><button>3</button><button>›</button>
                </div>
            </div>
        </section>

        <div class="bottom-grid">
            <section class="panel">
                <div class="panel-head">
                    <div><h2>Akses Cepat</h2><p>Navigasi pengelolaan data</p></div>
                </div>
                <div class="quick-grid">
                    <a class="quick-link" href="<?= site_url('hospital/pasien') ?>">
                        <div class="quick-icon ic-green">♙</div><div><strong>Data Pasien</strong><small>Informasi pasien</small></div>
                    </a>
                    <a class="quick-link" href="<?= site_url('hospital/kunjungan') ?>">
                        <div class="quick-icon ic-orange">▤</div><div><strong>Kunjungan</strong><small>Jadwal dan layanan</small></div>
                    </a>
                    <a class="quick-link" href="<?= site_url('hospital/dokter') ?>">
                        <div class="quick-icon ic-blue">✚</div><div><strong>Data Dokter</strong><small>Dokter dan spesialisasi</small></div>
                    </a>
                    <a class="quick-link" href="<?= site_url('hospital/diagnosis') ?>">
                        <div class="quick-icon ic-red">♡</div><div><strong>Diagnosis</strong><small>Data diagnosis pasien</small></div>
                    </a>
                </div>
            </section>
            <section class="panel">
                <div class="panel-head">
                    <div><h2>Ringkasan Layanan</h2><p>Informasi operasional</p></div>
                </div>
                <div class="activity-list">
                    <div class="activity">
                        <div class="activity-icon ic-green">✓</div>
                        <div><strong>Poli Umum</strong><p>Layanan konsultasi umum</p></div>
                        <span class="status status-green">Buka</span>
                    </div>
                    <div class="activity">
                        <div class="activity-icon ic-blue">✚</div>
                        <div><strong>Poli Gigi</strong><p>Layanan kesehatan gigi</p></div>
                        <span class="status status-green">Buka</span>
                    </div>
                    <div class="activity">
                        <div class="activity-icon ic-orange">♡</div>
                        <div><strong>Poli Jantung</strong><p>Layanan spesialis jantung</p></div>
                        <span class="status status-green">Buka</span>
                    </div>
                </div>
            </section>
        </div>

        <?php else: ?>
        <section class="panel table-panel">
            <div class="panel-head">
                <div>
                    <h2>Daftar <?= html_escape($title) ?></h2>
                    <p>Informasi dan pengelolaan data rumah sakit</p>
                </div>
                <span class="status status-green">● Sistem Informasi</span>
            </div>
            <div class="table-tools">
                <label class="search">⌕
                    <input id="tableSearch" type="search" placeholder="Cari data..." oninput="filterTable()">
                </label>
                <button class="btn" onclick="window.print()">⇩ Cetak Data</button>
            </div>
            <div class="table-scroll">
                <table id="dataTable">
                    <thead><tr>
                        <?php foreach ($headers as $header): ?>
                            <th><?= html_escape(strtoupper($header)) ?></th>
                        <?php endforeach; ?>
                        <th>AKSI</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($rows as $row): ?>
                    <tr>
                        <?php foreach ($row as $index => $cell): ?>
                        <td>
                            <?php if ($index === 1 && $page === 'pasien'): ?>
                                <div class="patient">
                                    <div class="patient-avatar"><?= html_escape(strtoupper(substr($cell,0,1))) ?></div>
                                    <div class="patient-name"><?= html_escape($cell) ?></div>
                                </div>
                            <?php elseif ($index === count($row)-1): ?>
                                <span class="status <?= in_array($cell, array('Aktif','Buka','Selesai')) ? 'status-green' : 'status-orange' ?>">
                                    <?= html_escape($cell) ?>
                                </span>
                            <?php else: ?>
                                <?= html_escape($cell) ?>
                            <?php endif; ?>
                        </td>
                        <?php endforeach; ?>
                        <td><button class="btn" onclick="alert('Fitur detail/edit perlu dihubungkan ke API.')">Detail ↗</button></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="table-footer">
                <span>Data contoh untuk desain awal — belum merupakan data pasien nyata.</span>
                <div class="pagination"><button class="active">1</button></div>
            </div>
        </section>
        <?php endif; ?>

        <div class="footer">Santosa Care · Hospital Information System · <?= date('Y') ?></div>
    </section>
</main>
</div>

<div id="modal" style="display:none;position:fixed;inset:0;background:#102b3266;z-index:100;align-items:center;justify-content:center;padding:20px">
    <div style="background:white;border-radius:14px;padding:25px;width:100%;max-width:440px;box-shadow:0 20px 80px #102b3226">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
            <h2 id="modalTitle" style="font-size:18px;margin:0">Tambah Data</h2>
            <button class="btn" onclick="hideForm()">✕</button>
        </div>
        <p style="color:#82919b;line-height:1.7">Form ini merupakan tampilan awal. Agar data tersimpan, form perlu dihubungkan ke endpoint POST API yang sesuai.</p>
        <button class="btn btn-primary" style="width:100%" onclick="hideForm()">Mengerti</button>
    </div>
</div>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}
function filterTable() {
    const input = document.getElementById('tableSearch');
    const table = document.getElementById('dataTable');
    if (!input || !table) return;
    const query = input.value.toLowerCase();
    table.querySelectorAll('tbody tr').forEach(function(row) {
        row.style.display = row.innerText.toLowerCase().includes(query) ? '' : 'none';
    });
}
function showForm() {
    const modal = document.getElementById('modal');
    const title = document.getElementById('modalTitle');
    if (modal && title) {
        title.textContent = 'Tambah <?= html_escape($title) ?>';
        modal.style.display = 'flex';
    }
}
function hideForm() {
    document.getElementById('modal').style.display = 'none';
}
function changeChart() {
    const period = document.getElementById('chartPeriod').value;
    const chart = document.getElementById('chart');
    if (!chart) return;
    const values = period === 'month'
        ? [[55,30],[65,35],[80,42],[72,38],[92,53],[60,31],[75,40]]
        : [[45,25],[67,38],[55,32],[82,44],[61,29],[92,53],[73,40]];
    chart.querySelectorAll('.chart-col').forEach(function(col, i) {
        col.querySelector('.bar-a').style.height = values[i][0] + '%';
        col.querySelector('.bar-b').style.height = values[i][1] + '%';
    });
}
document.addEventListener('click', function(event) {
    const modal = document.getElementById('modal');
    if (event.target === modal) hideForm();
});
</script>
</body>
</html>