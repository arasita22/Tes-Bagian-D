<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Hospital_api_model extends CI_Model
{
    private $base;
    private $token;
    public function __construct()
    {
        parent::__construct();
        $this->config->load('hospital_api', TRUE);
        $this->base = rtrim($this->config->item('hospital_api_base_url', 'hospital_api'), '/');
        $this->token = $this->config->item('hospital_api_token', 'hospital_api');
    }
    public function get($endpoint)
    {
        $url = $this->base . '/' . ltrim($endpoint, '/');
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            $headers = array('Accept: application/json');
            if (!empty($this->token)) $headers[] = 'Authorization: Bearer ' . $this->token;
            curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER=>TRUE, CURLOPT_TIMEOUT=>5, CURLOPT_HTTPHEADER=>$headers));
            $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            if ($raw !== FALSE && $code >= 200 && $code < 300) {
                $json = json_decode($raw, TRUE);
                if (is_array($json)) return array('ok'=>TRUE, 'data'=>$this->normalize($json), 'error'=>'');
            }
            return array('ok'=>FALSE, 'data'=>array(), 'error'=>'API belum dapat diakses. Periksa URL endpoint dan server API.');
        }
        return array('ok'=>FALSE, 'data'=>array(), 'error'=>'Ekstensi cURL PHP belum aktif.');
    }
    private function normalize($json)
    {
        if (isset($json['data']) && is_array($json['data'])) return isset($json['data'][0]) ? $json['data'] : (array_key_exists(0, $json['data']) ? $json['data'] : array($json['data']));
        if (isset($json['results']) && is_array($json['results'])) return $json['results'];
        if (isset($json[0])) return $json;
        return array($json);
    }
}
