
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hospital extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
    }

    public function index()
    {
        $this->dashboard();
    }

    public function dashboard()
    {
        $this->render_page('dashboard', 'Dashboard');
    }

    public function pasien()
    {
        $this->render_page('pasien', 'Data Pasien');
    }

    public function dokter()
    {
        $this->render_page('dokter', 'Data Dokter');
    }

    public function kunjungan()
    {
        $this->render_page('kunjungan', 'Data Kunjungan');
    }

    public function unit()
    {
        $this->render_page('unit', 'Unit Layanan');
    }

    public function diagnosis()
    {
        $this->render_page('diagnosis', 'Data Diagnosis');
    }

    private function render_page($page, $title)
    {
        $data['page'] = $page;
        $data['title'] = $title;

        $this->load->view('hospital/layout', $data);
    }
}