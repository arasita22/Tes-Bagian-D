
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    // GET: api/dashboard/summary
    public function summary()
    {
        $response = array(
            'status' => true,
            'message' => 'Dashboard summary API berhasil diakses',
            'filters' => array(
                'date_from' => $this->input->get('date_from'),
                'date_to' => $this->input->get('date_to')
            ),
            'data' => array(
                'total_pasien' => 0,
                'total_dokter' => 0,
                'total_kunjungan' => 0
            )
        );

        $this->send_json($response);
    }

    // GET: api/patients
    public function patients()
    {
        $page = (int) $this->input->get('page');
        $limit = (int) $this->input->get('limit');
        $search = trim((string) $this->input->get('search'));

        if ($page < 1) {
            $page = 1;
        }

        if ($limit < 1) {
            $limit = 10;
        }

        if ($limit > 100) {
            $limit = 100;
        }

        // Pastikan koneksi database tersedia.
        $this->load->database();

        if (!$this->db->table_exists('pasien')) {
            $this->send_json(array(
                'status' => false,
                'message' => 'Tabel pasien belum ditemukan di database.'
            ), 500);
            return;
        }

        // Filter pencarian nama.
        $this->db->from('pasien');

        if ($search !== '') {
            $this->db->like('nama', $search);
        }

        $total = $this->db->count_all_results();

        // Ambil data sesuai halaman.
        $this->db->from('pasien');

        if ($search !== '') {
            $this->db->like('nama', $search);
        }

        $patients = $this->db
            ->limit($limit, ($page - 1) * $limit)
            ->get()
            ->result_array();

        $response = array(
            'status' => true,
            'message' => 'Daftar pasien berhasil diambil',
            'pagination' => array(
                'page' => $page,
                'limit' => $limit,
                'total_data' => $total,
                'total_pages' => (int) ceil($total / $limit)
            ),
            'filters' => array(
                'search' => $search
            ),
            'data' => $patients
        );

        $this->send_json($response);
    }

    private function send_json($data, $http_code = 200)
    {
        $this->output
            ->set_status_header($http_code)
            ->set_content_type('application/json')
            ->set_output(json_encode($data));
    }
}